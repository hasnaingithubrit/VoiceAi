package com.jarvis.voice

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MsgListener : NotificationListenerService() {
    private val otp = Regex("(?i)otp|verification|code|pin|password|passcode")
    private val digits = Regex("\\d{4,8}")

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val app = Inbox.PKGS[sbn.packageName] ?: return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras
        if (ex.getBoolean("android.isGroupConversation")) return          // groups ignore
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        if (text.contains("new messages") || title == "WhatsApp") return
        if (otp.containsMatchIn(text) && digits.containsMatchIn(text)) return  // OTP kabhi nahi
        var act: Notification.Action? = null
        n.actions?.forEach { a -> if (act == null && a.remoteInputs?.isNotEmpty() == true) act = a }
        Inbox.add(Msg(title, text, app, System.currentTimeMillis(), act))
    }
}

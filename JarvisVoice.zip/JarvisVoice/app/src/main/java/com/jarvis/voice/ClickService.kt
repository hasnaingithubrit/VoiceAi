package com.jarvis.voice

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ClickService : AccessibilityService() {
    companion object {
        @Volatile var instance: ClickService? = null
        @Volatile var armedAt = 0L
        fun arm() { armedAt = System.currentTimeMillis() }
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (armedAt == 0L) return
        if (System.currentTimeMillis() - armedAt > 25000) { armedAt = 0L; return }
        val root = rootInActiveWindow ?: return
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val nodes = root.findAccessibilityNodeInfosByViewId(id)
            if (nodes.isNotEmpty()) {
                var node: AccessibilityNodeInfo? = nodes[0]
                while (node != null && !node.isClickable) node = node.parent
                if (node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    armedAt = 0L
                    return
                }
            }
        }
    }
}

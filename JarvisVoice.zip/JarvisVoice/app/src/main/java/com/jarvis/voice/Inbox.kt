package com.jarvis.voice

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle

data class Msg(val sender: String, val text: String, val app: String, val time: Long, val action: Notification.Action?)

object Inbox {
    val PKGS = mapOf(
        "com.whatsapp" to "WhatsApp",
        "com.whatsapp.w4b" to "WhatsApp Business",
        "com.google.android.apps.messaging" to "SMS",
        "com.samsung.android.messaging" to "SMS",
        "com.android.mms" to "SMS"
    )
    private val list = ArrayList<Msg>()

    @Synchronized fun add(m: Msg) { list.add(m); if (list.size > 30) list.removeAt(0) }
    @Synchronized fun latest(n: Int): List<Msg> = list.takeLast(n).reversed()
    @Synchronized fun find(sender: String): Msg? {
        val q = sender.lowercase().trim()
        return list.lastOrNull { q.isEmpty() || it.sender.lowercase().contains(q) }
    }
    @Synchronized fun clear() = list.clear()

    fun reply(ctx: Context, m: Msg, text: String): Boolean {
        val a = m.action ?: return false
        val ris = a.remoteInputs ?: return false
        val i = Intent()
        val b = Bundle()
        ris.forEach { b.putCharSequence(it.resultKey, text) }
        RemoteInput.addResultsToIntent(ris, i, b)
        return try { a.actionIntent.send(ctx, 0, i); true } catch (e: PendingIntent.CanceledException) { false }
    }
}

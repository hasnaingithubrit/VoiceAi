package com.jarvis.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var sr: SpeechRecognizer? = null
    private lateinit var logView: TextView
    private lateinit var status: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var settingsPanel: ScrollView
    private lateinit var langBtn: Button
    private val codes = listOf("ur-PK", "hi-IN", "en-IN")
    private val names = listOf("اردو (Urdu)", "हिन्दी (Hindi)", "English")
    private var li = 0
    private lateinit var tools: Tools
    private lateinit var agent: Agent
    private val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS)
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tools = Tools(this)
        agent = Agent(this, tools)
        tts = TextToSpeech(this) { st ->
            ttsReady = st == TextToSpeech.SUCCESS
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) {}
                override fun onDone(id: String?) { if (tools.hasPending()) runOnUiThread { listen() } }
            })
        }
        buildUi()
        if (prefs.getString("key", "").isNullOrBlank()) showSettings(true)
        else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(perms, 1)
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE)
        setBackgroundColor(Color.parseColor("#0f3b47")); setOnClickListener { f() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#04070d"))
            setPadding(dp(14), dp(30), dp(14), dp(12))
        }
        root.addView(TextView(this).apply {
            text = "J.A.R.V.I.S"; textSize = 26f; setTextColor(Color.parseColor("#2fe6ff"))
            typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            text = "Tayyar. Mic dabayein aur bolein."; setTextColor(Color.parseColor("#9fb4bd"))
            gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(10))
        }
        root.addView(status)
        val mic = Button(this).apply {
            text = "🎤  BOLO"; textSize = 22f; setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#2fe6ff")); setOnClickListener { listen() }
        }
        root.addView(mic, LinearLayout.LayoutParams(-1, dp(90)))

        val row = LinearLayout(this)
        langBtn = btn(names[li]) { li = (li + 1) % codes.size; langBtn.text = names[li] }
        row.addView(langBtn, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("■ STOP") { stopAll() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("⚙ Settings") { showSettings(settingsPanel.visibility != View.VISIBLE) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)

        logView = TextView(this).apply {
            setTextColor(Color.parseColor("#d7f6ff")); textSize = 15f; setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        logScroll = ScrollView(this).apply { addView(logView) }
        root.addView(logScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val s = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val key = EditText(this).apply {
            hint = "Gemini API key"; setText(prefs.getString("key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        val model = EditText(this).apply {
            hint = "Model"; setText(prefs.getString("model", "gemini-2.5-flash"))
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        s.addView(key); s.addView(model)
        s.addView(btn("Save") {
            prefs.edit().putString("key", key.text.toString().trim())
                .putString("model", model.text.toString().trim().ifEmpty { "gemini-2.5-flash" }).apply()
            agent.reset(); showSettings(false)
            Toast.makeText(this, "Save ho gaya", Toast.LENGTH_SHORT).show()
        })
        fun sw(label: String, k: String, def: Boolean) = android.widget.Switch(this).apply {
            text = label; setTextColor(Color.WHITE); isChecked = prefs.getBoolean(k, def)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(k, v).apply() }
        }
        s.addView(sw("Call/SMS/WhatsApp: bina poochay karo", "direct", true))
        s.addView(sw("Reply: bina poochay bhejo", "directReply", false))
        s.addView(btn("1) Permissions allow karo (mic, call, sms, contacts)") { requestPermissions(perms, 1) })
        s.addView(btn("2) Notification access on karo (messages ke liye)") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        s.addView(btn("3) Accessibility on karo (WhatsApp auto-send, camera band)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        s.addView(btn("4) Battery: No restrictions") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        s.addView(btn("Messages/history saaf karo") { Inbox.clear(); agent.reset(); addLog("History saaf kar di.") })
        settingsPanel = ScrollView(this).apply { addView(s); visibility = View.GONE }
        root.addView(settingsPanel, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showSettings(v: Boolean) {
        settingsPanel.visibility = if (v) View.VISIBLE else View.GONE
        logScroll.visibility = if (v) View.GONE else View.VISIBLE
    }

    private fun addLog(s: String) {
        logView.append(s + "\n\n")
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun stopAll() {
        tts.stop(); sr?.cancel(); tools.cancelPending()
        status.text = "Ruk gaya. Tayyar."
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(perms, 1); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addLog("Speech recognition nahi mila. Google app install/update karein."); return
        }
        tts.stop()
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status.text = "🎙 Sun raha hoon..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Samajh raha hoon..." }
            override fun onError(e: Int) { status.text = "Awaaz nahi suni (code $e). Mic dobara dabayein." }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onResults(res: Bundle?) {
                val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) status.text = "Kuch samajh nahi aaya." else handle(t)
            }
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, codes[li])
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1))
    }

    private fun handle(text: String) {
        addLog("Aap: $text")
        status.text = "Soch raha hoon..."
        Thread {
            val reply = try { agent.handle(text, codes[li]) } catch (e: Exception) { agent.reset(); "Error: ${e.message}" }
            runOnUiThread { say(reply) }
        }.start()
    }

    private fun say(t: String) {
        addLog("JARVIS: $t")
        status.text = "Tayyar."
        if (!ttsReady) return
        val r = tts.setLanguage(Locale.forLanguageTag(codes[li]))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale("en", "IN"))
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u1")
    }

    override fun onDestroy() {
        sr?.destroy(); tts.shutdown(); super.onDestroy()
    }
}
